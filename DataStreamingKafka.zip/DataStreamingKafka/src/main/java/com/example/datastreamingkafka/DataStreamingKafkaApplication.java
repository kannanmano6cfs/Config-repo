package com.example.datastreamingkafka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataStreamingKafkaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataStreamingKafkaApplication.class, args);
	}

}
