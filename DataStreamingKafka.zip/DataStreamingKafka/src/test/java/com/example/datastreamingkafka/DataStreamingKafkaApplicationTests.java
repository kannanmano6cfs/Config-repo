package com.example.datastreamingkafka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataStreamingKafkaApplicationTests {

	@Test
	void contextLoads() {
	}

}
